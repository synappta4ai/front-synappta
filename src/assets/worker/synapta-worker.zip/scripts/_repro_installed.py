"""Repro: corre UN job con el worker instalado (python embeddable + deps del .exe).

Uso (desde la carpeta worker instalada):
    <LOCALAPPDATA>\\SynaptaWorker\\python\\python.exe <este script> MODELO [modo]
"""

import json
import os
import subprocess
import sys
import threading
import time
from dataclasses import asdict

sys.path.insert(0, os.getcwd())
from engines.base import load_catalog  # noqa: E402

model = sys.argv[1] if len(sys.argv) > 1 else "SD-Tiny-Test"
out = os.path.join(os.getcwd(), "_repro_out")
os.makedirs(out, exist_ok=True)

spec = load_catalog()[model]
print("spec:", json.dumps(asdict(spec), ensure_ascii=False))

cmd = [sys.executable, "-u", "-m", "engines.worker_host",
       json.dumps(asdict(spec)), "auto"]
proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                        stderr=None, text=True, encoding="utf-8")

job = {
    "cmd": "job",
    "steps": 0,
    "out_dir": out,
    "request": {
        "job_id": "repro1",
        "prompt": "Generate an astronaut cat in space.",
        "negative_prompt": "",
        "width": 64 if spec.mode == "image" else 832,
        "height": 64 if spec.mode == "image" else 480,
        "num_frames": 8,
        "fps": 16,
        "seed": 1,
    },
}
proc.stdin.write(json.dumps(job) + "\n")
proc.stdin.flush()

t0 = time.time()


def reader():
    for line in proc.stdout:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            print("[non-json]", line[:300])
            continue
        print(f"  {time.time() - t0:6.1f}s {msg}")
        if msg.get("type") == "event" and msg.get("status") in (
            "COMPLETED", "FAILED", "CANCELLED"
        ):
            break


threading.Thread(target=reader, daemon=True).start()
try:
    proc.wait(timeout=int(os.environ.get("REPRO_TIMEOUT", "900")))
finally:
    try:
        proc.stdin.write(json.dumps({"cmd": "shutdown"}) + "\n")
        proc.stdin.flush()
    except OSError:
        pass
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
print("exit:", proc.returncode)
print("out:", os.listdir(out))
