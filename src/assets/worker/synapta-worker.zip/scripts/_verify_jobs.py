"""Verificación end-to-end del worker instalado (downloadable).

Arranca el gRPC del worker instalado y le pide dos jobs reales — chico de
imagen y Wan 1.3B de video — como lo hace el back por el bridge, e imprime los
eventos. Al final comprueba que el artefacto exista y que el bridge sepa
resolverlo (artifact_file_path).

    python scripts/_verify_jobs.py [modelo ...]
"""

import asyncio
import os
import subprocess
import sys
import time
from pathlib import Path

WORKER = Path(os.environ.get("VERIFY_WORKER_DIR",
                             Path(os.environ["LOCALAPPDATA"]) / "SynaptaWorker" / "worker"))
PY = Path(os.environ.get("VERIFY_PY",
                         Path(os.environ["LOCALAPPDATA"]) / "SynaptaWorker" / "python" / "python.exe"))

sys.path.insert(0, str(WORKER))
os.chdir(WORKER)  # igual que el worker instalado (cwd = carpeta del worker)
import grpc  # noqa: E402
import inference_pb2  # noqa: E402
import inference_pb2_grpc  # noqa: E402
from bridge.agent import artifact_file_path  # noqa: E402

JOBS = [
    ("SD-Tiny-Test", "image", "Generate an astronaut cat in space.", 64, 64, 0),
    ("Wan2.1-T2V-1.3B", "video", "Generate an astronaut cat in space.", 832, 480, 8),
]


def run_job(stub, model, mode, prompt, width, height, frames):
    req = inference_pb2.MediaGenerationRequest(
        job_id=f"verify_{model}_{int(time.time())}",
        mode=mode, model_name=model, prompt=prompt,
        width=width, height=height, num_frames=frames, fps=16,
    )
    print(f"\n=== {model} ({mode}) ===", flush=True)
    def stream():
        for ev in stub.GenerateMedia(req, timeout=3600):
            print(f"  {ev.percentage:6.1f}% {ev.status} out={ev.output_file_path!r} "
                  f"err={ev.error_message[:160]!r}", flush=True)
            if ev.status in ("COMPLETED", "FAILED", "CANCELLED"):
                return ev
        return None
    return stream()


def main() -> int:
    log = open(WORKER / "_verify_server.log", "w", encoding="utf-8")
    env = {**os.environ, "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1"}
    srv = subprocess.Popen([str(PY), "server.py"], cwd=str(WORKER), env=env,
                           stdout=log, stderr=subprocess.STDOUT)
    try:
        with grpc.insecure_channel("127.0.0.1:50051") as ch:
            stub = inference_pb2_grpc.InferenceServiceStub(ch)
            for _ in range(120):
                try:
                    stub.ListModels(inference_pb2.ListModelsRequest(), timeout=2)
                    break
                except grpc.RpcError:
                    time.sleep(1)
            else:
                print("el gRPC no levantó", flush=True)
                return 1
            only = set(sys.argv[1:])
            ok = True
            for model, mode, prompt, w, h, frames in JOBS:
                if only and model not in only:
                    continue
                ev = run_job(stub, model, mode, prompt, w, h, frames)
                if ev is None or ev.status != "COMPLETED":
                    ok = False
                    continue
                path = artifact_file_path(ev.output_file_path)
                exists = os.path.isfile(path)
                size = os.path.getsize(path) if exists else 0
                print(f"  artefacto: {path} existe={exists} bytes={size}", flush=True)
                ok = ok and exists and size > 0
            print("VERIFY_JOBS:", "OK" if ok else "FAIL", flush=True)
            return 0 if ok else 1
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=15)
        except subprocess.TimeoutExpired:
            srv.kill()
        log.close()


if __name__ == "__main__":
    raise SystemExit(main())
