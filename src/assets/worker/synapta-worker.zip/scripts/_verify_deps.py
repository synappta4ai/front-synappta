"""Verificación del instalador: corre install_deps() sobre la instalación real.

Uso:  .venv/Scripts/python.exe scripts/_verify_deps.py [carpeta]
Sin argumento usa el directorio por defecto del instalador
(%LOCALAPPDATA%\\SynaptaWorker), que es el que crea SynaptaWorker-Setup.exe.
"""

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s",
                    stream=sys.stdout, force=True)

from installer import core  # noqa: E402

workdir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else core.default_dir()
print("workdir:", workdir, flush=True)
py = core.python_path(workdir)

core.install_deps(py, workdir)
print("DEPS_OK torch:", core.torch_version(py, workdir), flush=True)

rc, lines = core.run_capture([
    py, "-c",
    "import torch,diffusers,transformers,huggingface_hub as h\n"
    "print('torch',torch.__version__,'cuda',torch.version.cuda,\n"
    "      'avail',torch.cuda.is_available())\n"
    "print('diffusers',diffusers.__version__,'transformers',transformers.__version__,\n"
    "      'hfhub',h.__version__)",
], cwd=workdir)
print("CHECK rc:", rc, "→", " | ".join(lines), flush=True)

rc = core.run([py, workdir / "worker" / "scripts" / "doctor.py"],
              cwd=workdir / "worker", timeout=300)
print("DOCTOR rc:", rc, flush=True)
