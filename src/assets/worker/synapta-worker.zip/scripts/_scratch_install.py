"""Verificación del instalador descargable: instalación real en una carpeta limpia.

    python scripts/_scratch_install.py <destino>
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from installer import core  # noqa: E402

dest = Path(sys.argv[1]).resolve()
t0 = time.time()
core.install(workdir=dest, payload_url=core.PAYLOAD_URL)
print(f"INSTALL_OK en {time.time() - t0:.0f}s → {dest}")
